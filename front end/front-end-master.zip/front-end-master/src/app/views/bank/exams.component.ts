import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'exams.component.html'
})
export class ExamsComponent{
    constructor(){}
}