import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'questions.component.html'
})
export class QuestionsComponent{
    constructor(){}
}