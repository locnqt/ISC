import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'parts.component.html'
})
export class PartsComponent{
    constructor(){}
}