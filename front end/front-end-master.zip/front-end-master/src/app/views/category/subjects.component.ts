import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'subjects.component.html'
})
export class SubjectsComponent{
    constructor(){}
}