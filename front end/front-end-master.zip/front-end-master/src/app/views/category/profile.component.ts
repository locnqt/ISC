import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'profile.component.html'
})
export class ProfileComponent{
    constructor(){}
}