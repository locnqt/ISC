import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'teachers.component.html'
})
export class TeachersComponent{
    constructor(){}
}