import { Component, ViewChild  } from '@angular/core';
@Component({
    templateUrl:'examinees.component.html'
})
export class ExamineesComponent{
    constructor(){}
}